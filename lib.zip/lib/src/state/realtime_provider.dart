import 'dart:async';
import 'package:flutter/foundation.dart';

import 'package:eldercare_app/src/config/env.dart';
import 'package:eldercare_app/src/core/constants.dart';
import 'package:eldercare_app/src/core/utils.dart';
import 'package:eldercare_app/src/data/api/api_client.dart';
import 'package:eldercare_app/src/data/api/vitals_api.dart';
import 'package:eldercare_app/src/data/mqtt/mqtt_service.dart';
import 'package:eldercare_app/src/domain/models/metric.dart';
import 'package:eldercare_app/src/domain/models/vital_point.dart';

class RealtimeProvider extends ChangeNotifier {
  final _api = VitalsApi(ApiClient(baseUrl: Env.apiBaseUrl));
  final _mqtt = MqttService(
    host: Env.mqttHost,
    username: Env.mqttUsername,
    password: Env.mqttPassword,
    tcpPort: Env.mqttTcpPort,
    wsPort: Env.mqttWsPort,
    wsPath: Env.mqttWsPath,
  );

  String userId = Env.defaultUserId;

  bool _initialized = false;
  bool isLoadingLatest = false;
  bool isLoadingHistory = false;

  String? error;

  VitalPoint? latest;
  Metric selectedMetric = Metric.hr;

  final List<VitalPoint> _livePoints = [];
  List<VitalPoint> get livePoints => List.unmodifiable(_livePoints);

  final List<VitalPoint> _historyPoints = [];
  List<VitalPoint> get historyPoints => List.unmodifiable(_historyPoints);

  StreamSubscription? _mqttSub;

  Future<void> init({String? userId}) async {
    if (_initialized) return;
    _initialized = true;

    if (userId != null && userId.isNotEmpty) this.userId = userId;

    await refreshLatest();
    await connectMqtt();

    // Gợi ý: load rộng hơn để không bị thiếu (ví dụ 30 ngày)
    await loadHistory(from: '-30d', to: 'now()', window: '10m');
  }

  Future<void> refreshLatest() async {
    try {
      isLoadingLatest = true;
      error = null;
      notifyListeners();

      latest = await _api.latest(userId: userId);
    } catch (e) {
      error = 'Latest error: $e';
    } finally {
      isLoadingLatest = false;
      notifyListeners();
    }
  }

  /// Load history theo range tương đối (giữ để dùng chung)
  Future<void> loadHistory({
    String from = '-30d',
    String to = 'now()',
    String window = '10m',
  }) async {
    try {
      isLoadingHistory = true;
      error = null;
      notifyListeners();

      final points = await _api.history(
        userId: userId,
        from: from,
        to: to,
        window: window,
      );
      points.sort((a, b) => a.time.compareTo(b.time));

      _historyPoints
        ..clear()
        ..addAll(points);
    } catch (e) {
      error = 'History error: $e';
    } finally {
      isLoadingHistory = false;
      notifyListeners();
    }
  }

  /// ✅ Load đúng 1 ngày LOCAL (00:00 local -> 24:00 local), query bằng UTC
  Future<void> loadHistoryForLocalDay({
    required DateTime dayLocal,
    String window = '10m',
  }) async {
    final startLocal = DateTime(dayLocal.year, dayLocal.month, dayLocal.day);
    final endLocal = startLocal.add(const Duration(days: 1));

    final startUtc = startLocal.toUtc();
    final endUtc = endLocal.toUtc();

    // IMPORTANT:
    // - Nếu backend/Flux của bạn dùng dạng range(start: $from, stop: $to)
    //   thì Influx Flux nhận time literal rất tốt qua time(v:"...").
    final from = 'time(v: "${startUtc.toIso8601String()}")';
    final to = 'time(v: "${endUtc.toIso8601String()}")';

    await loadHistory(from: from, to: to, window: window);
  }

  Future<void> connectMqtt() async {
    try {
      error = null;
      final id = '${userId}_${kIsWeb ? "web" : "io"}';
      await _mqtt.connect(clientId: id);

      final topic = 'eldercare/$userId/telemetry';
      _mqtt.subscribe(topic);

      _mqttSub?.cancel();
      _mqttSub = _mqtt.messages.listen((m) {
        if (m.topic != topic) return;
        final json = safeJsonMap(m.payload);
        final p = VitalPoint.fromJson(json);

        latest = p;

        _livePoints.add(p);
        if (_livePoints.length > AppConstants.liveMaxPoints) {
          _livePoints.removeRange(0, _livePoints.length - AppConstants.liveMaxPoints);
        }
        notifyListeners();
      });
    } catch (e) {
      error = 'MQTT error: $e';
      notifyListeners();
    }
  }

  void setMetric(Metric metric) {
    selectedMetric = metric;
    notifyListeners();
  }

  List<VitalPoint> liveSeriesFor(Metric metric) {
    return _livePoints.where((p) => p.valueOf(metric) != null).toList();
  }

  /// ✅ Lọc theo ngày LOCAL (không lệch UTC+7)
  List<VitalPoint> historyForLocalDay(DateTime dayLocal) {
    return _historyPoints.where((p) {
      final t = p.time.toLocal();
      return t.year == dayLocal.year && t.month == dayLocal.month && t.day == dayLocal.day;
    }).toList();
  }

  /// (Giữ lại nếu bạn vẫn muốn lọc theo UTC-day)
  List<VitalPoint> historyForUtcDay(DateTime dayUtc) {
    final d = DateTime.utc(dayUtc.year, dayUtc.month, dayUtc.day);
    final next = d.add(const Duration(days: 1));
    return _historyPoints.where((p) => !p.time.isBefore(d) && p.time.isBefore(next)).toList();
  }

  @override
  void dispose() {
    // Flutter dispose không nên async
    _mqttSub?.cancel();
    _mqtt.dispose();
    super.dispose();
  }
}
