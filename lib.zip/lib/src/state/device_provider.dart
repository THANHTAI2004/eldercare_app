import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:eldercare_app/src/config/env.dart';
import 'package:eldercare_app/src/domain/models/device.dart';

class DeviceProvider extends ChangeNotifier {
  static const _devicesKey = 'devices';
  static const _currentIdKey = 'current_device_id';

  final List<Device> _devices = [];
  Device? _current;
  bool _loaded = false;

  List<Device> get devices => List.unmodifiable(_devices);
  Device? get current => _current;

  /// Load từ SharedPreferences (chỉ 1 lần)
  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;

    final prefs = await SharedPreferences.getInstance();

    final jsonStr = prefs.getString(_devicesKey);
    if (jsonStr != null && jsonStr.isNotEmpty) {
      try {
        final list = jsonDecode(jsonStr) as List<dynamic>;
        _devices
          ..clear()
          ..addAll(
            list.map((e) => Device.fromJson(e as Map<String, dynamic>)),
          );
      } catch (_) {
        _devices.clear();
      }
    }


    if (_devices.isEmpty) {
      _current = null;
    }

    final currentId = prefs.getString(_currentIdKey);
    _current = _devices.firstWhere(
          (d) => d.id == currentId,
      orElse: () => _devices.first,
    );

    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    final list = _devices.map((d) => d.toJson()).toList();
    await prefs.setString(_devicesKey, jsonEncode(list));
    await prefs.setString(_currentIdKey, _current?.id ?? _devices.first.id);
  }

  /// Thêm / cập nhật thiết bị từ QR
  Future<void> addFromQr(String qrRaw) async {
    final dev = Device.fromQr(qrRaw);

    final existingIndex = _devices.indexWhere((d) => d.id == dev.id);
    if (existingIndex >= 0) {
      _devices[existingIndex].name = dev.name;
      _current = _devices[existingIndex];
    } else {
      _devices.add(dev);
      _current = dev;
    }

    await _save();
    notifyListeners();
  }

  Future<void> rename(String id, String newName) async {
    final d = _devices.firstWhere((e) => e.id == id, orElse: () => _current!);
    final name = newName.trim();
    if (name.isNotEmpty) {
      d.name = name;
      await _save();
      notifyListeners();
    }
  }

  Future<void> remove(String id) async {
    if (_devices.length <= 1) return; // luôn giữ ít nhất 1 thiết bị

    _devices.removeWhere((d) => d.id == id);

    if (_current?.id == id) {
      _current = _devices.first;
    }

    await _save();
    notifyListeners();
  }

  Future<void> setCurrent(String id) async {
    final d = _devices.firstWhere((e) => e.id == id);
    _current = d;
    await _save();
    notifyListeners();
  }
}
