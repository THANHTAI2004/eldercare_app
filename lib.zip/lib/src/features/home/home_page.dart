import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:eldercare_app/src/app/routes.dart';
import 'package:eldercare_app/src/domain/models/vital_point.dart';
import 'package:eldercare_app/src/state/device_provider.dart';
import 'package:eldercare_app/src/state/realtime_provider.dart';
import 'package:eldercare_app/src/widgets/feature_button.dart';
import 'package:eldercare_app/src/widgets/health_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _didInit = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_didInit) return;
    _didInit = true;

    // Khi vào Home lần đầu: init realtime theo thiết bị hiện tại
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final device = context.read<DeviceProvider>().current;
      context.read<RealtimeProvider>().init(userId: device?.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<RealtimeProvider>();
    final device = context.watch<DeviceProvider>().current;

    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Eldercare'),
            if (device != null)
              Text(
                device.name,
                style: Theme.of(context).textTheme.bodySmall,
              ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Quản lý thiết bị',
            onPressed: () => Navigator.pushNamed(context, AppRoutes.devices),
            icon: const Icon(Icons.qr_code_2),
          ),
          IconButton(
            tooltip: 'Làm mới',
            onPressed: p.isLoadingLatest ? null : () => p.refreshLatest(),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (p.error != null) ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: scheme.errorContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    p.error!,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: scheme.onErrorContainer,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
              ],

              // Card tổng quan (HR, SpO2, Temp, RR)
              HealthCard(point: p.latest),
              const SizedBox(height: 24),

              // Nút History
              Row(
                children: [
                  Expanded(
                    child: FeatureButton(
                      icon: Icons.history,
                      title: 'History',
                      subtitle: 'Theo ngày/giờ',
                      onTap: () =>
                          Navigator.pushNamed(context, AppRoutes.history),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // 💓 Card ECG nằm dưới nút History
              EcgCard(point: p.latest),
            ],
          ),
        ),
      ),
    );
  }
}

/// Card hiển thị điện tâm đồ (waveform ECG từ ngực)
class EcgCard extends StatelessWidget {
  const EcgCard({super.key, required this.point});

  final VitalPoint? point;

  @override
  Widget build(BuildContext context) {
    final p = point;
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    final hr = p?.hr;
    final leadOff = p?.leadOff;

    String leadText;
    Color leadColor;
    bool disabled;

    if (p == null) {
      leadText = 'Chưa có dữ liệu ECG';
      leadColor = scheme.outline;
      disabled = true;
    } else if (leadOff == 1) {
      leadText = 'Chưa gắn điện cực ngực';
      leadColor = scheme.error;
      disabled = true;
    } else {
      leadText = hr == null ? 'Điện cực OK' : 'Điện cực OK • HR ~ $hr bpm';
      leadColor = scheme.primary;
      disabled = false;
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ECG điện tâm đồ',
              style: textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            Text(
              'Tín hiệu ECG từ cảm biến ngực (AD8232).',
              style: textTheme.bodySmall?.copyWith(
                color: scheme.outline,
              ),
            ),
            const SizedBox(height: 12),

            // Waveform ECG
            SizedBox(
              height: 120,
              child: EcgWave(
                color: disabled ? scheme.outline.withOpacity(0.6) : scheme.primary,
                background: scheme.surfaceVariant.withOpacity(0.4),
                thickness: 2.0,
              ),
            ),
            const SizedBox(height: 10),

            // Trạng thái lead
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: leadColor.withOpacity(0.08),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: leadColor.withOpacity(0.5)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    disabled ? Icons.highlight_off : Icons.favorite_border,
                    size: 18,
                    color: leadColor,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    leadText,
                    style: textTheme.bodySmall?.copyWith(
                      color: leadColor,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Widget vẽ waveform ECG kiểu PQRST (demo).
/// Hiện tại dùng mẫu mô phỏng, sau này nếu có dữ liệu ECG thật thì
/// chỉ cần thay [samples] bằng dữ liệu thực.
class EcgWave extends StatelessWidget {
  const EcgWave({
    super.key,
    required this.color,
    required this.background,
    this.thickness = 2.0,
  });

  final Color color;
  final Color background;
  final double thickness;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _EcgPainter(
        color: color,
        background: background,
        thickness: thickness,
      ),
      size: Size.infinite,
    );
  }
}

class _EcgPainter extends CustomPainter {
  _EcgPainter({
    required this.color,
    required this.background,
    required this.thickness,
  });

  final Color color;
  final Color background;
  final double thickness;

  // Mẫu PQRST đơn giản (biên độ chuẩn hóa -1..1)
  List<double> _basePattern() {
    return [
      0, 0, 0, // iso
      0.1, 0.2, 0.1, 0, // P
      0, 0, -0.2, // Q
      1.0, // R
      -0.4, 0, 0.05, // S
      0.2, 0.1, 0, // T
      0, 0, 0, 0, 0, // iso
    ];
  }

  @override
  void paint(Canvas canvas, Size size) {
    final bgPaint = Paint()
      ..color = background
      ..style = PaintingStyle.fill;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Offset.zero & size,
        const Radius.circular(12),
      ),
      bgPaint,
    );

    final w = size.width;
    final h = size.height;
    if (w <= 0 || h <= 0) return;

    // Lặp pattern nhiều lần cho đầy chiều ngang
    final pattern = _basePattern();
    final repeat = 4;
    final samples = <double>[];
    for (int r = 0; r < repeat; r++) {
      samples.addAll(pattern);
    }

    final n = samples.length;
    if (n < 2) return;

    final midY = h / 2;
    final amp = h * 0.35; // biên độ

    final path = Path();
    for (int i = 0; i < n; i++) {
      final x = w * i / (n - 1);
      final y = midY - samples[i] * amp;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    final linePaint = Paint()
      ..color = color
      ..strokeWidth = thickness
      ..style = PaintingStyle.stroke
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(path, linePaint);
  }

  @override
  bool shouldRepaint(covariant _EcgPainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.background != background ||
        oldDelegate.thickness != thickness;
  }
}
