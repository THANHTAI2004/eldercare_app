import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:eldercare_app/src/state/device_provider.dart';
import 'package:eldercare_app/src/features/devices/device_qr_scanner_page.dart';
import 'package:eldercare_app/src/features/home/home_page.dart';

class DevicePage extends StatelessWidget {
  const DevicePage({super.key});

  /// Quét QR để thêm thiết bị
  Future<void> _scanAndAdd(BuildContext context) async {
    final code = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const DeviceQrScannerPage()),
    );
    if (code == null || code.isEmpty) return;

    final deviceProv = context.read<DeviceProvider>();

    // QR code chứa userId hoặc chuỗi định danh thiết bị
    await deviceProv.addFromQr(code);

    // Nếu logic addFromQr tự set current thì không cần làm gì thêm ở đây
    // Nếu không, bạn có thể tự setCurrent theo current vừa thêm:
    // final current = deviceProv.current;
    // if (current != null) {
    //   await deviceProv.setCurrent(current.id);
    // }
  }

  /// Thêm thiết bị bằng cách nhập userId (cho máy không có camera)
  Future<void> _showManualAddDialog(BuildContext context) async {
    final nameController = TextEditingController();
    final userIdController = TextEditingController();

    final result = await showDialog<_ManualDeviceResult>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Thêm thiết bị thủ công'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Tên thiết bị',
                  hintText: 'VD: Thiết bị phòng ngủ',
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: userIdController,
                decoration: const InputDecoration(
                  labelText: 'userId',
                  hintText: 'VD: u01',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, null),
              child: const Text('Hủy'),
            ),
            FilledButton(
              onPressed: () {
                final userId = userIdController.text.trim();
                final name = nameController.text.trim();
                if (userId.isEmpty) return; // bắt buộc userId

                Navigator.pop(
                  ctx,
                  _ManualDeviceResult(
                    userId: userId,
                    name: name,
                  ),
                );
              },
              child: const Text('Lưu'),
            ),
          ],
        );
      },
    );

    if (result == null) return;

    final deviceProv = context.read<DeviceProvider>();

    // Dùng lại logic cũ: addFromQr nhận chuỗi userId/QR → truyền trực tiếp userId
    await deviceProv.addFromQr(result.userId);

    // Nếu có nhập tên thì đổi tên luôn thiết bị hiện tại
    final current = deviceProv.current;
    if (current != null && result.name.isNotEmpty) {
      await deviceProv.rename(current.id, result.name);
    }
  }

  Future<void> _renameDialog(
      BuildContext context,
      String id,
      String oldName,
      ) async {
    final ctrl = TextEditingController(text: oldName);
    final provider = context.read<DeviceProvider>();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Đổi tên thiết bị'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Tên hiển thị',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Lưu'),
          ),
        ],
      ),
    );

    if (ok == true) {
      await provider.rename(id, ctrl.text);
    }
  }

  Future<void> _confirmDelete(BuildContext context, String id) async {
    final provider = context.read<DeviceProvider>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xóa thiết bị?'),
        content: const Text(
          'Thiết bị sẽ bị xóa khỏi danh sách trên app (không ảnh hưởng ESP).',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Hủy'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Xóa'),
          ),
        ],
      ),
    );

    if (ok == true) {
      await provider.remove(id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Thiết bị'),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Nút thêm thiết bị bằng userId
          FloatingActionButton.extended(
            heroTag: 'manualAddDevice',
            onPressed: () => _showManualAddDialog(context),
            icon: const Icon(Icons.edit),
            label: const Text('Nhập userId'),
          ),
          const SizedBox(height: 12),

          // Nút quét QR
          FloatingActionButton.extended(
            heroTag: 'scanAddDevice',
            onPressed: () => _scanAndAdd(context),
            icon: const Icon(Icons.qr_code_scanner),
            label: const Text('Quét QR thêm thiết bị'),
          ),
        ],
      ),
      body: SafeArea(
        child: Consumer<DeviceProvider>(
          builder: (context, p, _) {
            final devices = p.devices;
            final currentId = p.current?.id;

            if (devices.isEmpty) {
              return Center(
                child: Text(
                  'Chưa có thiết bị nào.\nNhấn nút bên dưới để quét QR hoặc nhập userId.',
                  textAlign: TextAlign.center,
                  style: textTheme.bodyMedium,
                ),
              );
            }

            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
              itemBuilder: (ctx, index) {
                final d = devices[index];
                final isCurrent = d.id == currentId;

                final initial = (d.name.isNotEmpty
                    ? d.name[0]
                    : (d.id.isNotEmpty ? d.id[0] : '?'))
                    .toUpperCase();

                return Card(
                  child: ListTile(
                    onTap: () async {
                      final deviceProv = context.read<DeviceProvider>();

                      // Đặt thiết bị hiện tại
                      await deviceProv.setCurrent(d.id);

                      if (!context.mounted) return;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const HomePage(),
                        ),
                      );
                    },
                    leading: CircleAvatar(
                      backgroundColor:
                      isCurrent ? scheme.primary : scheme.surfaceVariant,
                      child: Text(initial),
                    ),
                    title: Text(d.name),
                    subtitle: Text('userId: ${d.id}'),
                    trailing: Wrap(
                      spacing: 4,
                      children: [
                        if (isCurrent)
                          Icon(
                            Icons.check_circle,
                            color: scheme.primary,
                            size: 20,
                          ),
                        IconButton(
                          icon: const Icon(Icons.edit),
                          tooltip: 'Đổi tên',
                          onPressed: () =>
                              _renameDialog(context, d.id, d.name),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          tooltip: 'Xóa',
                          onPressed: () => _confirmDelete(context, d.id),
                        ),
                      ],
                    ),
                  ),
                );
              },
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemCount: devices.length,
            );
          },
        ),
      ),
    );
  }
}

/// Kết quả dialog thêm thiết bị thủ công
class _ManualDeviceResult {
  _ManualDeviceResult({required this.userId, required this.name});

  final String userId;
  final String name;
}
