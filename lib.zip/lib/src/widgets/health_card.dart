import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:eldercare_app/src/domain/models/vital_point.dart';

class HealthCard extends StatelessWidget {
  const HealthCard({super.key, required this.point});

  final VitalPoint? point;

  @override
  Widget build(BuildContext context) {
    final p = point;
    final time = p?.time;

    Widget item(String label, String value) {
      return Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Text(label, style: Theme.of(context).textTheme.labelMedium),
              const SizedBox(height: 6),
              Text(value, style: Theme.of(context).textTheme.titleLarge),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Thông số mới nhất', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),

            Row(
              children: [
                item('HR', p?.hr?.toString() ?? '--'),
                const SizedBox(width: 10),
                item('SpO₂', p?.spo2?.toString() ?? '--'),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                item('Temp', p?.temp == null ? '--' : p!.temp!.toStringAsFixed(1)),
                const SizedBox(width: 10),
                item('RR', p?.rr?.toString() ?? '--'),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              time == null ? 'Chưa có dữ liệu' : 'Cập nhật: ${DateFormat('HH:mm:ss dd/MM').format(time.toLocal())}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
